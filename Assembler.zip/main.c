#include "preassembler.h"

int main(){

file_handler();

return 0;
}
