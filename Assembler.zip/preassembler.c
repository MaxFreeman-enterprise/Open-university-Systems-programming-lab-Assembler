#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINE_LENGTH 80


struct Macro{
    char *name;
    int start_macro;
    int end_macro;
};



void file_handler(){
        FILE *asmFile;
        char line[MAX_LINE_LENGTH];
        asmFile = fopen("assembler_test.txt","r");
        

        if(asmFile != NULL) {
            while (!feof(asmFile)) {
                fgets(line, MAX_LINE_LENGTH, asmFile);
                printf("the file data is = %s\n", line);
            }
            fclose(asmFile);
        }
        else{
            printf("\nUnable to open the assembler_test.asm file");
        }

       /* ptr = fopen("assembler_test.asm", "r");

        if (ptr == NULL){
            printf("file cant be opened \n");
        }

        printf("content of this file are \n");

        while(fgets(line,MAX_LINE_LENGTH,ptr) != NULL)
        {
            printf("%s",line);
        }

    fclose(ptr);*/


}



/*
 * 0) create output file - fopen fclose
 * 1) loop through file - fgets
 * 2) parse each line to fine "macro" - strtok strcmp
 * 3) if macro -> insert to linstlist.
 * 3.1) else copy line to output file - fprintf
 *
 * need to pay attention to pointers, example to check if name points on another name,
 * fopen, to check if the name of the file is correct, for example, file name ends with "ps,am",
 * need to check if we received macro name and ect, for example:
 * "macro m1
 * 1
 * 2
 * 3
 * end macro
 * m1"
 * functions that could help to implement this algo are: ftell,fseek,
 */
